Filelist:
ATtiny817_Xplained_Mini_layer_plots_release_rev4.pdf : PCB Layer Plots
BOM\Bill of Materials Print-ATtiny817_Xplained_Mini_release_rev4.xls : BOM, fitted components
ExportSTEP\ATtiny817_Xplained_Mini_release_rev4.step : 3D Model of PCBA
NC Drill\ATtiny817_Xplained_Mini_release_rev4.drl : Drill files, gerber
NC Drill\ATtiny817_Xplained_Mini_release_rev4.drr : Drill Files Report
ODB\ATtiny817_Xplained_Mini_release_rev4.tgz : ODB++ Files
Pick Place\Pick Place for ATtiny817_Xplained_Mini_release_rev4.txt : Pick and Place file, component placement
Test Points\Assembly Testpoint Report for ATtiny817_Xplained_Mini_release_rev4.txt : Assembly Testpoint report, txt
Test Points\Assembly Testpoint Report for ATtiny817_Xplained_Mini_release_rev4.csv : Assembly Testpoint report, csv
NC Drill\ATtiny817_Xplained_Mini_-SlotHoles_release_rev4.txt : Drill files, ASCII-SlotHoles
NC Drill\ATtiny817_Xplained_Mini_-RoundHoles_release_rev4.txt : Drill files, ASCII-RoundHoles
ATtiny817_Xplained_Mini_design_documentation_release_rev4.PDF : Design Documentation with Bom
Gerber\ATtiny817_Xplained_Mini_release_rev4.GP2 : Gerber files for Power Plane
Gerber\ATtiny817_Xplained_Mini_release_rev4.GP1 : Gerber files for Ground Plane
Gerber\ATtiny817_Xplained_Mini_release_rev4.GBS : Gerber files for Bottom Solder
Gerber\ATtiny817_Xplained_Mini_release_rev4.GM1 : Gerber files for Mechanical 1
Gerber\ATtiny817_Xplained_Mini_release_rev4.GTP : Gerber files for Top Paste
Gerber\ATtiny817_Xplained_Mini_release_rev4.GBL : Gerber files for Bottom Layer
Gerber\ATtiny817_Xplained_Mini_release_rev4.GBO : Gerber files for Bottom Overlay
Gerber\ATtiny817_Xplained_Mini_release_rev4.GTS : Gerber files for Top Solder
Gerber\ATtiny817_Xplained_Mini_release_rev4.GTL : Gerber files for Top Layer
Gerber\ATtiny817_Xplained_Mini_release_rev4.GTO : Gerber files for Top Overlay
